import { useState, createContext } from "react";
export const MultiStepContext = createContext();

const StepContext = ({ children }) => {
  const [step, setStep] = useState(0);
  const [stepData, setStepData] = useState([]);
  const [finalData, setFinalData] = useState([]);

  return (
    <div>
      <MultiStepContext.Provider
        value={{
          step,
          setStep,
          stepData,
          setStepData,
          finalData,
          setFinalData,
        }}
      >
        {children}
      </MultiStepContext.Provider>
    </div>
  );
};

export default StepContext;
