import "./App.css";
import Layout from "./components/layout/Layout";
import StepContext from "./StepContext";

function App() {
  return (
    <StepContext>
      <Layout />
    </StepContext>
  );
}

export default App;
