import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { useContext, useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { MultiStepContext } from "../../StepContext";
import "../../assets/css/UserInfo.css";

function UserInfo() {
  // storing initial values
  const initialValues = {
    firstName: "",
    lastName: "",
    mobile: "",
    email: "",
    gender: "",
    dob: "",
    address: "",
    password: "",
    confirmPassword: "",
  };
  const [userData, setUserData] = useState(initialValues);
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);
  const [isSubmit, setIsSubmit] = useState(false);

  useEffect(() => {
    if (stepData) {
      setUserData(stepData);
    }
  }, [stepData]);

  const showPrev = () => {
    if (step !== 0) {
      setStep(step - 1);
    } else if (step === 1) {
      setStep(step);
    }
  };

  // defining userInfo for validation
  const userInfoSchema = Yup.object().shape({
    firstName: Yup.string()
      .min(2, "Firstname too Short!")
      .max(50, "Firstname too Long!")
      .required("Name is Required"),

    lastName: Yup.string()
      .min(2, "Last Name too Short!")
      .max(50, "Last Name too Long!")
      .required("Last Name is Required"),

    mobile: Yup.string().required("mobile is required"),

    email: Yup.string().email("Invalid email").required("Email is required"),

    gender: Yup.string().required("Gender is Requiered"),

    dob: Yup.string().required("dob is required"),

    address: Yup.string()
      .min(2, "Address too Short!")
      .max(50, "Address too Long!")
      .required("Address is Required"),

    password: Yup.string()
      .min(8, "Password too short")
      .max(16, "Password too long")
      .required("Password is Required")
      .matches(
        /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/,
        "Password must contain atleast a digit a lowercase, a uppercase ,special charcter and a digit"
      ),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password"), null], "Passwords must match")
      .required("Confirm Password is Required"),
  });

  return (
    <div className="registraion-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={userData}
        // validationSchema={userInfoSchema}
        enableReinitialize={true}
        onSubmit={(values) => {
          setIsSubmit(true)
          setStepData(values);
        }}
      >
        {({ errors, touched }) => (
          <Form className="user-info-form my-4">
            <div className="row my-2">
              <h1>user Info</h1>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="firstName">First Name</label>
                  <Field name="firstName" className="form-control" />
                  {errors.firstName && touched.firstName ? (
                    <div className="error">{errors.firstName}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="lastName">Last Name </label>
                  <Field name="lastName" className="form-control" />
                  {errors.lastName && touched.lastName ? (
                    <div className="error">{errors.lastName}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="mobile">Mobile</label>
                  <Field name="mobile" className="form-control" />
                  {errors.mobile && touched.mobile ? (
                    <div className="error">{errors.mobile}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="email">Email</label>
                  <Field name="email" className="form-control" />
                  {errors.email && touched.email ? (
                    <div className="error">{errors.email}</div>
                  ) : null}
                </div>
              </div>
            </div>

            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="gender-radio">Gender</label>
                  <div className="gender-radio">
                    <label>
                      <Field type="radio" name="gender" value="Male" />
                      Male
                    </label>
                    <label>
                      <Field type="radio" name="gender" value="Female" />
                      Female
                    </label>
                    {errors.gender && touched.gender ? (
                      <div className="error">{errors.gender}</div>
                    ) : null}
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="dob">DOB</label>
                  <Field type="date" name="dob" className="form-control" />
                  {errors.dob && touched.dob ? (
                    <div className="error">{errors.dob}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group textarea">
                  <label htmlFor="address">Address</label>
                  <Field
                    as={"textarea"}
                    name="address"
                    rows="5"
                    cols="20 "
                    className="form-control"
                  />
                  {errors.address && touched.address ? (
                    <div className="error">{errors.address}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="password"> Password</label>
                  <Field
                    name="password"
                    type="password"
                    className="form-control"
                  />
                  {errors.password && touched.password ? (
                    <div className="error">{errors.password}</div>
                  ) : null}
                </div>
                <div className="col-md-8">
                  <div className="form-group">
                    <label htmlFor="password"> Confirm Password</label>
                    <Field
                      name="confirmPassword"
                      type="password"
                      className="form-control"
                    />
                    {errors.confirmPassword && touched.confirmPassword ? (
                      <div className="error">{errors.confirmPassword}</div>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
            <div className="roww my-5 ">
              <div className="col-md-10 d-flex justify-content-between">
                <Button disabled={step === 0 ? true : false}  onClick={() => showPrev()}>
                  Back
                </Button>
                <Button type="submit">Save</Button>
                <Button disabled={!isSubmit} onClick={() => setStep((step + 1) % 5)}>Next</Button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default UserInfo;
