import React, { useContext } from "react";
import { Button } from "react-bootstrap";
import { Stepper, Step, StepLabel } from "@mui/material";
import UserInfo from "./UserInfo";
import EducationDetails from "./EducationDetails";
import { MultiStepContext } from "../../StepContext";
import WorkExperience from "./WorkExperience";
import PhotoUploadation from "./PhotoUploadation";
import Confirmation from "./Confirmation";
import "../../assets/css/Main.css";

function Main() {
  const { step } = useContext(MultiStepContext);

  function showStep(step) {
    switch (step) {
      case 0:
        return <UserInfo />;
      case 1:
        return <EducationDetails />;
      case 2:
        return <WorkExperience />;
      case 3:
        return <PhotoUploadation />;
      case 4:
        return <Confirmation />;
      default:
        return <div>Return to home</div>;
    }
  }

  return (
    <div className="container my-4">
      <div className="row justify-content-center">
        <div className="col-md-12 ">
          <Stepper activeStep={step} orientation="horizontal">
            <Step>
              <StepLabel>User Info</StepLabel>
            </Step>
            <Step>
              <StepLabel>Education</StepLabel>
            </Step>
            <Step>
              <StepLabel>Work Experience</StepLabel>
            </Step>
            <Step>
              <StepLabel>Upload Photo</StepLabel>
            </Step>
            <Step>
              <StepLabel>Confirmation</StepLabel>
            </Step>
          </Stepper>
          <div className="row">
            <div className="col-md-12">
              <div className="forms-container">{showStep(step)}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main;
