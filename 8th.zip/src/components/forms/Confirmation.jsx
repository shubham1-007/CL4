import React from "react";

function Confirmation() {
  return (
    <div >
      Confirmation
    </div>
  );
}

export default Confirmation;
