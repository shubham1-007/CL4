import { React, useState, useContext, useEffect } from "react";
import Table from "react-bootstrap/Table";
import { MultiStepContext } from "../../StepContext";
import "../../assets/css/forms/confirmation.css";
import { Button } from "react-bootstrap";
import axios from "axios";

function Confirmation() {
  const url = "http://localhost:3004/user";
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);

  const handleSubmit = () => {
    console.log(stepData);
    axios
      .post(url, stepData)
      .then((res) => {
        alert("data posted");
      })
      .catch((err) => {
        alert(err);
      });
  };

  const showPrev = () => {
    if (step !== 0) {
      setStep(step - 1);
    } else if (step === 1) {
      setStep(step);
    }
  };

  return (
    <div className="confirmation-page my-3">
      <div className="user-info my-2">{stepData.firstName}</div>
      <div className="educational-info my-2">{stepData.university}</div>
      <div className="work-experience my-2">{stepData.organisation}</div>
      <div className="photo my-2">
        <img src={stepData.image} width={100} height={100} alt="photo" />
      </div>
      <div className="btn my-2">
        <Button onClick={() => showPrev()}>Back</Button>
        <Button onClick={() => handleSubmit()} variant="primary">
          Submit
        </Button>
      </div>
    </div>
  );
}

export default Confirmation;
