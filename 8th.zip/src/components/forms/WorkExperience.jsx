import React from 'react'

function WorkExperience() {
  return (
    <div>WorkExperience</div>
  )
}

export default WorkExperience