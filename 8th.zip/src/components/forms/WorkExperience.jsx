import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import { Button } from "react-bootstrap";
import * as Yup from "yup";
import { useContext } from "react";
import { MultiStepContext } from "../../StepContext";

function WorkExperience() {
  const [WorkExperience, setWorkExperience] = useState({
    organisation: "",
    companyAddress: "",
    yearsWorked: "",
    designation: "",
  });
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);
  const [isSubmit, setIsSubmit] = useState(false);

  useEffect(() => {
    if (stepData) {
      setWorkExperience(stepData);
    }
  }, [stepData]);

  const showPrev = () => {
    if (step !== 0) {
      setStep(step - 1);
    } else if (step === 1) {
      setStep(step);
    }
  };

  const educationDetailsSchema = Yup.object().shape({});
  return (
    <div className="registraion-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={WorkExperience}
        enableReinitialize={true}
        // validationSchema={educationDetailsSchema}
        onSubmit={(values) => {
          setStepData(values);
          setIsSubmit(true);
        }}
      >
        {({ errors, touched }) => (
          <Form className="user-info-form my-4">
            <div className="row my-2">
              <h1>Work Experience</h1>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="organisation">Organisation</label>
                  <Field name="organisation" className="form-control" />
                  {errors.organisation && touched.organisation ? (
                    <div className="error">{errors.organisation}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group textarea">
                  <label htmlFor="companyAddress">Address</label>
                  <Field
                    as={"textarea"}
                    name="companyAddress"
                    rows="5"
                    cols="20 "
                    className="form-control"
                  />
                  {errors.companyAddress && touched.companyAddress ? (
                    <div className="error">{errors.companyAddress}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="yearsWorked">Years Worked</label>
                  <Field name="yearsWorked" className="form-control" />
                  {errors.yearsWorked && touched.yearsWorked ? (
                    <div className="error">{errors.yearsWorked}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="designation">Designation</label>
                  <Field name="designation" className="form-control" />
                  {errors.designation && touched.designation ? (
                    <div className="error">{errors.designation}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="roww my-5 ">
              <div className="col-md-10 d-flex justify-content-between">
                <Button onClick={() => showPrev()}>Back</Button>
                <Button type="submit">Save</Button>
                <Button
                  disabled={!isSubmit}
                  onClick={() => setStep((step + 1) % 5)}
                >
                  Next
                </Button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default WorkExperience;
