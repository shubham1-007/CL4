import { React, useState, useContext, useEffect } from "react";
import { Button } from "react-bootstrap";
import { MultiStepContext } from "../../StepContext";

function PhotoUploadation() {
  const [file, setFile] = useState();
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);
  const [isValid, setValid] = useState(false);

  useEffect(() => {
    if (stepData.image) {
      setFile(stepData.image);
      setValid(true)
    }
  }, [stepData]);

  const showPrev = () => {
    if (step !== 0) {
      setStep(step - 1);
    } else if (step === 1) {
      setStep(step);
    }
  };

  function handleChange(e) {
    // console.log(e.target.files);
    setFile(URL.createObjectURL(e.target.files[0]));
    setValid(true)
    setStepData({ ...stepData, image: URL.createObjectURL(e.target.files[0]) });
  }

  return (
    <div>
      <div className="photo-upload-container">
        <h2>Add Image</h2>
        <input type="file" onChange={handleChange} />
        {file && <img src={file} width={100} height={100} />}
      </div>
      <div className="roww my-5 ">
        <div className="col-md-10 d-flex justify-content-between">
          <Button onClick={() => showPrev()}>Back</Button>
          <Button disabled={!isValid} onClick={() => setStep((step + 1) % 5)}>Next</Button>
        </div>
      </div>
    </div>
  );
}

export default PhotoUploadation;
