import React from "react";
import "../../assets/css/layout/Layout.css";
import Header from "./Header";
import Footer from "./Footer";
import Main from "../forms/Main";
function Layout() {
  return (
    <>
      <div className="layout-wrapper">
        <header>
          <Header />
        </header>
        <main>
          <div className="main-section">
           <Main />
          </div>
        </main>
      </div>
      <footer>
        <Footer />
      </footer>
    </>
  );
}

export default Layout;
