import React from "react";
import "../../assets/css/layout/Header.css";
import logo from "../../assets/images/logo.png";
import "react-toastify/dist/ReactToastify.css";

function Header() {
  return (
    <div>
      <div className="header">
        <div className="nav-container">
          <div className="navbar-brand">
            <img
              alt=""
              src={logo}
              width="70"
              height="70"
              className="d-inline-block align-center"
            />
            <div className="divider"></div>
            <div className="brand-text">
              <h1>Multistep Forms</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Header;
