import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import "../../assets/css/admin/EditAccess.css";
import { Button } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
function EditAccess() {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    role: "",
    topics: [],
  });

  // getting id for editing topics
  let { id } = useParams();
  //url
  const url = "http://localhost:3004/users";

  useEffect(() => {
    axios.get(`${url}/${id}/`).then((res) => {
      setUser(res.data);
    });
    // eslint-disable-next-line
  }, []);


  // function to edit the topics
  const editTopics = (user) => {
    axios
      .put(`${url}/${id}`, user)
      .then((res) => {
        toast.success("Post edited Successfully !");
        setTimeout(() => {
          navigate("/admin");
        }, 1000);
      })
      .catch((err) => {
        toast.error("Error in Editing post");
      });
  };

  // defining subjects schema
  const topicSchema = Yup.object().shape({
    topics: Yup.array().min(1, "please select atleast one topic"),
  });

  return (
    <div className="edit-wrapper">
      <div className="container edit-container">
        <Formik
          initialValues={user}
          validationSchema={topicSchema}
          enableReinitialize={true}
          onSubmit={(values, { resetForm }) => {
            setUser(values);
            editTopics(values);
            resetForm();
          }}
        >
          {({ errors, touched }) => (
            <div className="form-wrapper">
              <div className="edit-access-header mb-3">
                <h3>Edit Access</h3>
              </div>
              <Form>
                <div className="row">
                  <div className="col-md-6 label">
                    <h4>Topics</h4>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-5">
                    <div className="checkbox">
                      <label>
                        <Field type="checkbox" name="topics" value="History" />
                        History
                      </label>
                    </div>
                  </div>
                  <div className="col-md-5">
                    <div className="checkbox">
                      <label>
                        <Field
                          type="checkbox"
                          name="topics"
                          value="Geography"
                        />
                        Geography
                      </label>
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-5">
                    <div className="checkbox">
                      <label>
                        <Field type="checkbox" name="topics" value="Science" />
                        Science
                      </label>
                    </div>
                  </div>
                  <div className="col-md-5">
                    <div className="checkbox">
                      <label>
                        <Field type="checkbox" name="topics" value="Maths" />
                        Maths
                      </label>
                    </div>
                  </div>
                </div>
                <div className="row d-flex justify-content-center align-items-center">
                  {errors.topics && touched.topics ? (
                    <div className="error">{errors.topics}</div>
                  ) : null}
                </div>
                <div className="row ">
                  <div className="edit-btn-group d-flex justify-content-around ">
                    <Button type="submit" variant="primary">
                      Submit
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        navigate(-1);
                      }}
                    >
                      Back
                    </Button>
                  </div>
                </div>
              </Form>
            </div>
          )}
        </Formik>
        <ToastContainer />
      </div>
    </div>
  );
}

export default EditAccess;
