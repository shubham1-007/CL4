import React from "react";
import "../../assets/css/layout/Layout.css";
function Footer() {
  // getting year from date
  var date = new Date();
  var year = date.getFullYear();
  return (
    <div className="footer">
      <div className="footer-wrapper">
        <div className="copyright">&copy; Copyright LMS {year}</div>
      </div>
    </div>
  );
}

export default Footer;
