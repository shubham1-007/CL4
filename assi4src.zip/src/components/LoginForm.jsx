import React, { Component } from "react";
import "../assets/css/LoginForm.css";
export class loginForm extends Component {
  constructor() {
    super();
    this.state = {
      email: "",
      password: "",
      emailError: "",
      passwordError: "",
      isFomValid: false,
    };
  }
  // function to submit the form
  handleSubmit = (event) => {
    event.preventDefault();
    this.validateForm();
  };

  // function to reset the form
  handleReset = () => {
    this.setState({ email: "" });
    this.setState({ emailError: "" });
    this.setState({ password: "" });
    this.setState({ passwordError: "" });
    this.setState({ isFomValid: false });
  };

  // function to validate the mail
  validateEmail = () => {
    let email = this.state.email; //storing useranme from state
    let emailPattern = /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/;
    // validations for email
    if (!email) {
      this.setState({ emailError: "Email is required" });
      return false;
    } else {
      if (!emailPattern.test(email)) {
        this.setState({
          emailError: "Enter a valid email",
        });
        return false;
      } else {
        this.setState({ emailError: "" }); // if No error
        return true;
      }
    }
  };

  // function to validate the password
  validatePassword = () => {
    let password = this.state.password; //storig password from state
    let passwordPattern =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@.#$!%*?&^])[A-Za-z\d@.#$!%*?&]/;

    // validation for password Field
    if (!password) {
      this.setState({ passwordError: "Password is required" });
      return false;
    } else {
      if (password.length < 3) {
        this.setState({ passwordError: "Password is too short" }); // checking if password is < 3
        return false;
      } else if (password.length > 16) {
        this.setState({ passwordError: "Password is too long" }); // checking if password is > 8
        return false;
      } else if (!passwordPattern.test(password)) {
        this.setState({
          passwordError:
            "Password must contain atleast a digit a lowercase, a uppercase ,special charcter and a digit",
        });
        return false;
      } else {
        this.setState({ passwordError: "" }); // No error in password
        return true;
      }
    }
  };

  // function to validate the form
  validateForm = () => {
    let isValidEmail = this.validateEmail();
    let isValidPassword = this.validatePassword();

    if (isValidEmail && isValidPassword) {
      this.setState({ isFomValid: true });
    } else {
      this.setState({ isFomValid: false });
    }
  };

  render() {
    return (
      <div className="login-wrapper">
        <div className="div">
          <div className="login-container">
            <h2>Login Form</h2>
            <form
              className="login-form"
              onSubmit={(event) => this.handleSubmit(event)}
            >
              {/* input for email  */}
              <div className="form-group">
                <div className="label">
                  <label htmlFor="email">Email</label>
                </div>
                <input
                  type="text"
                  id="email"
                  name="email"
                  className="form-control"
                  onChange={(e) => this.setState({ email: e.target.value })}
                  onBlur={this.validateEmail}
                  value={this.state.email}
                />
                <div className="error">
                  {this.state.emailError ? this.state.emailError : null}
                </div>
              </div>
              {/* input for password  */}
              <div className="form-group password">
                <div className="label">
                  <label htmlFor="password">Password</label>
                </div>
                <input
                  type="password"
                  id="password"
                  name="password"
                  className="form-control"
                  onChange={(e) => this.setState({ password: e.target.value })}
                  onBlur={this.validatePassword}
                  value={this.state.password}
                />
                <div className="error">
                  {this.state.passwordError ? this.state.passwordError : null}
                </div>
              </div>
              {/* log in button  */}
              <div className="button-group">
                <button type="submit">LOGIN</button>
                <button
                  type="button"
                  style={{ background: "red" }}
                  onClick={this.handleReset}
                >
                  RESET
                </button>
              </div>
            </form>
          </div>
        </div>

        <div className="div">
          {/* displaying the form details  */}
          {this.state.isFomValid && (
            <div className="login-details ">
              <div className="wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Email</th>
                      <th>Password</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>{this.state.email}</td>
                      <td>{this.state.password}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default loginForm;
