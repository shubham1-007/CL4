import React, { useEffect, useState } from "react";
import axios from "axios";
import Table from "react-bootstrap/Table";
import "../assets/css/Dashboard.css";
import { useNavigate } from "react-router-dom";
function Dashboard() {
  // api url
  const url = "http://localhost:3004/posts";
  const [allPosts, setAllPosts] = useState([]);
  const navigate = useNavigate();

  // getting all posts from the api
  useEffect(() => {
    axios.get(url).then((res) => {
      setAllPosts(res.data);
    });
  }, []);

  //function to geta all posts
  const getAllPosts = () => {
    axios.get(url).then((res) => {
      setAllPosts(res.data);
    });
  };

  //function to add new post
  const addPost = () => {
    navigate("/add");
  };
  //function to handle Edit Posts
  const editPost = (post) => {
    navigate(`/edit/:${post.id}`)
  };

  const deletePost = (id) => {
    axios.delete(`${url}/${id}`).then((res) => {});
    getAllPosts();
  };

  return (
    <div className="posts-container">
      <button onClick={() => addPost()}>Add Posts</button>
      <div className="table-container">
        <Table responsive>
          <thead>
            <tr>
              <th>#</th>
              <th>Id</th>
              <th>Title</th>
              <th>Body</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {allPosts.map((post) => {
              return (
                <tr key={post.id}>
                  <td>{post.id}</td>
                  <td>{post.id}</td>
                  <td>{post.title}</td>
                  <td>{post.body}</td>
                  <td>
                    <div className="actions-btn-group">
                      <button onClick={() => editPost(post)}>Edit</button>
                      <button onClick={() => deletePost(post.id)}>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </div>
    </div>
  );
}

export default Dashboard;

// <div className="posts-container w-100">
//       {allPosts.map((post) => {
//         return (
//           <div className="table" key={post.id}>
//             <Table responsive>
//               <thead>
//                 <tr>
//                   <th>#</th>
//                   <th>ID</th>
//                   <th>Title</th>
//                   <th>Body</th>
//                   <th>Actions</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 <tr>
//                   <td>1</td>
//                   <td></td>
//                 </tr>
//                 <tr>
//                   <td>2</td>
//                   {Array.from({ length: 12 }).map((_, index) => (
//                     <td key={index}>Table cell {index}</td>
//                   ))}
//                 </tr>
//                 <tr>
//                   <td>3</td>
//                   {Array.from({ length: 12 }).map((_, index) => (
//                     <td key={index}>Table cell {index}</td>
//                   ))}
//                 </tr>
//               </tbody>
//             </Table>
//           </div>
//         );
//       })}
//     </div>
