import { React, useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { Formik, Field, Form } from "formik";
import * as Yup from "yup";
import { Button } from "react-bootstrap";
import axios from "axios";

import "../assets/css/AddEdit.css";
function AddEdit() {
  // getting id for editing post
  let { id } = useParams();
  // api url
  const url = "http://localhost:3004/posts";

  // hook to store the query
  // definining initial values
  const [initialValues, setInitialValues] = useState({
    title: "",
    body: "",
  });

  useEffect((id) => {
    getPost(id);
  });

  //function to get the post details for given id
  const getPost = () => {
    axios.get(`${url}${id}`).then((res) => {
      console.log(res.data);
    });
  };

  //validation schema for query info
  const postSchema = Yup.object().shape({
    title: Yup.string()
      .min(4, "Title is too short")
      .max(25, "Title is too long")
      .required("Title is required"),
    body: Yup.string()
      .min(5, "Content is too short")
      .max(50, "Content is too long")
      .required("Content is required"),
  });

  return (
    <div>
      <div className="post-form-wrapper">
        <Formik
          initialValues={initialValues}
          validationSchema={postSchema}
          onSubmit={(values, { resetForm }) => {
            setInitialValues(values);
            resetForm();
          }}
        >
          {({ errors, touched }) => (
            <Form>
              <div className="post-form">
                <h1>{id ? "Edit Form" : "Add Form"}</h1>
                <div className="form-group">
                  <div>
                    <label htmlFor="title">Title</label>
                  </div>
                  <Field name="title" />
                  {errors.title && touched.title ? (
                    <div className="error">{errors.title}</div>
                  ) : null}
                </div>
                <div className="form-group">
                  <div>
                    <label htmlFor="body">Content</label>
                  </div>
                  <Field as={"textarea"} name="body" />
                  {errors.body && touched.body ? (
                    <div className="error">{errors.body}</div>
                  ) : null}
                </div>
                <Button type="submit" variant="primary">
                  Edit/Add
                </Button>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );

  /* return (
    <div className="post-input-form">

    </div>
  ) */
}

export default AddEdit;
