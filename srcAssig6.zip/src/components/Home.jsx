import React from "react";
import "../assets/css/Home.css";
function Home() {
  return <div className="main-wrapper">
    
  </div>;
}

export default Home;
