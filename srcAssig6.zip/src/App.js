import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/layout/Layout";
import Dashboard from "./components/Dashboard";
import AddEdit from "./components/AddEdit";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="Dashboard" element={<Dashboard />} />
          <Route path="add" element={<AddEdit />} />
          <Route path="edit:id" element={<AddEdit />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
