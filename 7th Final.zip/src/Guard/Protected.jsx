import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Protected(props) {
  const { Component } = props;
  const navigate = useNavigate();
  useEffect(() => {
    var user = JSON.parse(localStorage.getItem("loggedUser"));
    // navigation based on user and its role
    if (user) {
      if (user.role === "Admin") {
        navigate("/Admin");
      } else if (user.role === "Student") {
        navigate("/Student");
      }
    } else {
      navigate("/login");
    }
    // eslint-disable-next-line
  }, []);
  return <Component />;
}

export default Protected;
