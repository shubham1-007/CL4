import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import "../assets/css/LoginForm.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function LoginForm() {
  const [dbcredentials, setDBCredentials] = useState([]);
  const initialUserCredentials = {
    email: "",
    password: "",
  };
  const url = "http://localhost:3004/users";

  useEffect(() => {
    getCredentials();
    if (localStorage.getItem("loggedUser")) {
      localStorage.removeItem("loggedUser");
    }
    // eslint-disable-next-line
  }, [localStorage.getItem("loggedUser")]);

  // function to get the database user credentials
  const getCredentials = () => {
    axios
      .get(url)
      .then((res) => {
        setDBCredentials(res.data);
      })
      .catch(() => {
        toast.error("Something went wrong");
      });
  };

  // function to login
  const login = (credentials) => {
    const loggedUser = dbcredentials.find(
      (dbUser) =>
        dbUser.email === credentials.email &&
        dbUser.password === credentials.password
    );
    if (loggedUser) {
      const user = {
        firstName: loggedUser.firstName,
        lastName: loggedUser.lastName,
        role: loggedUser.role,
        id: loggedUser.id,
      };

      // storing user to localstorage
      localStorage.setItem("loggedUser", JSON.stringify(user));
      if (loggedUser.role === "Student") {
        toast.success("Logged In");
        setTimeout(() => {
          navigate("/student");
        }, 500);
      } else if (loggedUser.role === "Admin") {
        toast.success("Logged In (Admin)");
        setTimeout(() => {
          navigate("/admin");
        }, 500);
      }
    } else {
      toast.error("Invalid Credentials");
    }
  };

  const navigate = useNavigate();
  // defining registrationSchema for validation
  const loginSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email").required("Email is required"),

    password: Yup.string()
      .min(8, "Password too short")
      .max(16, "Password too long")
      .required("Password is Required")
      .matches(
        /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/,
        "Password must contain atleast a digit a lowercase, a uppercase ,special charcter and a digit"
      ),
  });

  return (
    <div className="login-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={initialUserCredentials}
        validationSchema={loginSchema}
        onSubmit={(values, { resetForm }) => {
          login(values);
          resetForm();
        }}
      >
        {({ errors, touched }) => (
          <Form className="login-form">
            <h2>Login </h2>
            <div className="roww">
              <div className="form-group">
                <label htmlFor="email"> Email</label>
                <Field name="email" type="email" />
                {errors.email && touched.email ? (
                  <div className="error">{errors.email}</div>
                ) : null}
              </div>
              {/* password  */}
              <div className="form-group">
                <label htmlFor="password"> Password</label>
                <Field name="password" type="password" />
                {errors.password && touched.password ? (
                  <div className="error">{errors.password}</div>
                ) : null}
              </div>
            </div>
            <div className="btn-group">
              <Button type="submit" variant="primary">
                Login
              </Button>
              <Button type="reset" variant="danger">
                RESET
              </Button>
            </div>
          </Form>
        )}
      </Formik>
      <ToastContainer />
    </div>
  );
}

export default LoginForm;
