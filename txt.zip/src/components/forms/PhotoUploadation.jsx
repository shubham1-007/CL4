import { React, useState, useContext, useEffect } from "react";
import { Button } from "react-bootstrap";
import { MultiStepContext } from "../../StepContext";
import "../../assets/css/forms/PhotoUploadation.css";

function PhotoUploadation() {
  const [file, setFile] = useState();
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);
  const [isValid, setValid] = useState(false);

  useEffect(() => {
    if (stepData.image) {
      setFile(stepData.image);
      setValid(true);
    }
  }, [stepData]);

  function handleChange(e) {
    setFile(URL.createObjectURL(e.target.files[0]));
    setValid(true);
    setStepData({ ...stepData, image: URL.createObjectURL(e.target.files[0]) });
  }

  return (
    <div className="user-info-form">
      <div className="row mb-5">
        <h1>Upload Photo</h1>
      </div>
      <div className="photo-upload-container">
        <input type="file" onChange={handleChange} className="form-control mb-5" />
        {file && <img src={file} width={300} height={300} />}
      </div>
      <div className="roww my-5 ">
        <div className="col-md-10 d-flex justify-content-between">
          <Button onClick={() => setStep(2)}>Back</Button>
          <Button disabled={!isValid} onClick={() => setStep((step + 1) % 5)}>
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}

export default PhotoUploadation;
