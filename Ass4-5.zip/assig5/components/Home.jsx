import React from 'react'
import '../assets/css/Home.css'
import headset from "../assets/images/headset.jpg"
import mobile from "../assets/images/mobile.jpg"
import laptop from "../assets/images/laptop.jpg"
import Button from 'react-bootstrap/Button';
function Home() {
  return (
    <div className="main-wrapper">
        {/* hero section with banner image  */}
        <div className="hero-section">
          <div className="hero-info">
            <h1>
              Shop with Shop Ease
            </h1>
            <h5>
              Exciting offers available
            </h5>
            {/* <Button>Get Started</Button> */}
            <Button variant="warning" className='btn'>Get Started</Button>{' '}
          </div>
        </div>
        {/* out products section   */}
        <div className="our-products">
          <div className="product">
            <div className="product-img">
              <img src={mobile} alt="mobile-image" />
            </div>
            <h3>
              Mobile
            </h3>
            <p>
              Apple iPhone
            </p>
          </div>
          <div className="product">
            <div className="product-img">
              <img src={laptop} alt="laptop-image" />
            </div>
            <h3>
              Laptop
            </h3>
            <p>
              Mac Book
            </p>
          </div>
          <div className="product">
            <div className="product-img">
              <img src={headset} alt="headset-image" />
            </div>
            <h3>
              Headset
            </h3>
            <p>
              Sony Headset
            </p>
          </div>
        </div>
      </div>
  )
}

export default Home