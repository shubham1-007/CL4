import React, { useState } from "react";
import "../assets/css/ContactUs.css";
import { Formik, Field, Form } from "formik";
import * as Yup from "yup";
import { Button } from "react-bootstrap";
function ContactUs() {
  // definining initial values
  const initialValues = {
    name: "",
    email: "",
    query: "",
  };
  // hook to store the query
  const [queryInfo, setQueryInfo] = useState(initialValues);
  const [isFormValid, setFormValid] = useState(false);

  //validation schema for query info
  const querySchema = Yup.object().shape({
    name: Yup.string()
      .min(4, "Name is too short")
      .max(25, "Name is too long")
      .required("Name is required"),
    email: Yup.string().email("Invalid email").required("Required"),
    query: Yup.string()
      .min(5, "Query is too short")
      .max(50, "Query is too long")
      .required("Query is required"),
  });

  return (
    <div>
      <div className="contact-form-wrapper">
        <Formik
          initialValues={initialValues}
          validationSchema={querySchema}
          onSubmit={(values, { resetForm }) => {
            setQueryInfo(values);
            setFormValid(true);
            resetForm();
          }}
        >
          {({ errors, touched }) => (
            <Form>
              <div className="contact-form">
                <h1>Contact Us </h1>
                <div className="form-group">
                  <div>
                    <label htmlFor="name">Name</label>
                  </div>
                  <Field name="name" />
                  {errors.name && touched.name ? (
                    <div className="error">{errors.name}</div>
                  ) : null}
                </div>
                <div className="form-group">
                  <div>
                    <label htmlFor="email">Email</label>
                  </div>
                  <Field name="email" />
                  {errors.email && touched.email ? (
                    <div className="error">{errors.email}</div>
                  ) : null}
                </div>
                <div className="form-group">
                  <div>
                    <label htmlFor="query">Query</label>
                  </div>
                  <Field as={"textarea"} name="query" row="5" cols="25" />
                  {errors.query && touched.query ? (
                    <div className="error">{errors.query}</div>
                  ) : null}
                </div>
                <Button type="submit" variant="primary">
                  Send Query
                </Button>
              </div>
            </Form>
          )}
        </Formik>
        {isFormValid && (
          <div className="query-details">
            <h2>Query Details</h2>
            <div className="query-details-container">
              <table>
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Query</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{queryInfo.name}</td>
                    <td>{queryInfo.email}</td>
                    <td>{queryInfo.query}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ContactUs;
