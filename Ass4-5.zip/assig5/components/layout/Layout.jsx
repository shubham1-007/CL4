import React from "react";
import { Outlet } from "react-router-dom";
import "../../assets/css/layout/Layout.css";
import Header from "./Header";
import Footer from "./Footer";
function Layout() {
  return (
    <>
      <div className="layout-wrapper">
        <header>
          <Header />
        </header>
        <main>
          <div className="main-section">
            <Outlet />
          </div>
        </main>
      </div>
      <footer>
        <Footer />
      </footer>
    </>
  );
}

export default Layout;
