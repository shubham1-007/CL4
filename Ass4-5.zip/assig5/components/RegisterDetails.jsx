import React from "react";
import { useOutletContext } from "react-router-dom";

function RegisterDetails(props) {
  // const details = props.details
  const details = useOutletContext();

  return (
    <div className="register-details">
      <div className="register-details">
        <h2>Registration Details</h2>
        <div className="reg-details-container">
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Country</th>
                <th>Hobbies</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{details.firstName}</td>
                <td>{details.lastName}</td>
                <td>{details.email}</td>
                <td>{details.password}</td>
                <td>{details.gender}</td>
                <td>{details.address}</td>
                <td>{details.country}</td>
                <td>{details.hobbies.join(",")}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default RegisterDetails;
