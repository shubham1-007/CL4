import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import "../assets/css/RegistrationForm.css";
import { useState } from "react";

// storing initial values
const initialValues = {
  firstName: "",
  lastName: "",
  email: "",
  password: "",
  gender: "",
  address: "",
  country: "",
  hobbies: [],
};

function RegistrationForm() {
  const [details, setDetails] = useState(initialValues);
  const [showDetails, setShowDetails] = useState(false);

  // defining registrationSchema for validation
  const registrationSchema = Yup.object().shape({
    firstName: Yup.string()
      .min(2, "Firstname too Short!")
      .max(50, "Firstname too Long!")
      .required("Name is Required"),
    lastName: Yup.string()
      .min(2, "Last Name too Short!")
      .max(50, "Last Name too Long!")
      .required("Last Name is Required"),
    email: Yup.string().email("Invalid email").required("Email is required"),
    password: Yup.string()
      .min(8, "Password too short")
      .max(16, "Password too long")
      .required("Password is Required")
      .matches(
        /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/,
        "Password must contain atleast a digit a lowercase, a uppercase ,special charcter and a digit"
      ),
    gender: Yup.string().required("Gender is Requiered"),
    address: Yup.string()
      .min(2, "Address too Short!")
      .max(50, "Address too Long!")
      .required("Address is Required"),
    country: Yup.string().required("Country is required"),
    hobbies: Yup.array()
      .min(1, "select atleast one hobby")
      .required("please select hobbies"),
  });

  return (
    <div className="registraion-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={initialValues}
        validationSchema={registrationSchema}
        onSubmit={(values, { resetForm }) => {
          setShowDetails(true);
          setDetails(values);
          resetForm();
          // alert("submit");
        }}
      >
        {({ errors, touched }) => (
          <Form className="register-form">
            <h2>Registration Form</h2>
            <div className="row">
              <div className="form-group">
                <label htmlFor="firstName">First Name</label>
                <Field name="firstName" />
                {errors.firstName && touched.firstName ? (
                  <div className="error">{errors.firstName}</div>
                ) : null}
              </div>

              <div className="form-group">
                <label htmlFor="lastName">Last Name</label>
                <Field name="lastName" />
                {errors.lastName && touched.lastName ? (
                  <div className="error">{errors.lastName}</div>
                ) : null}
              </div>
            </div>
            <div className="row">
              <div className="form-group">
                <label htmlFor="email"> Email</label>
                <Field name="email" type="email" />
                {errors.email && touched.email ? (
                  <div className="error">{errors.email}</div>
                ) : null}
              </div>
              {/* password  */}
              <div className="form-group">
                <label htmlFor="password"> Password</label>
                <Field name="password" type="password" />
                {errors.password && touched.password ? (
                  <div className="error">{errors.password}</div>
                ) : null}
              </div>
            </div>
            <div className="row long">
              {/* gender  */}
              <div className="form-group gender-radio">
                <label htmlFor="gender-radio">Gender</label>
                <label>
                  <Field type="radio" name="gender" value="Male" />
                  Male
                </label>
                <label>
                  <Field type="radio" name="gender" value="Female" />
                  Female
                </label>
                {errors.gender && touched.gender ? (
                  <div className="error">{errors.gender}</div>
                ) : null}
              </div>
              {/* address  */}
              <div className="form-group textarea">
                <label htmlFor="address">Address</label>
                <Field as={"textarea"} name="address" rows="5" cols="32" />
                {errors.address && touched.address ? (
                  <div className="error">{errors.address}</div>
                ) : null}
              </div>
            </div>
            <div className="row">
              {/* country  */}
              <div className="form-group  dropdown">
                <label htmlFor="country">Country</label>
                <Field name="country" as="select">
                  <option value="">select</option>
                  <option value="india">India</option>
                  <option value="uk">UK</option>
                  <option value="us">US</option>
                </Field>
                {errors.gender && touched.gender ? (
                  <div className="error">{errors.gender}</div>
                ) : null}
              </div>
              {/* hobbies  */}
              <div className="form-group checkboxes">
                <div className="checkbox">
                  <Field type="checkbox" name="hobbies" value="Reading" />
                  <label>Reading</label>
                </div>
                <div className="checkbox">
                  <Field type="checkbox" name="hobbies" value="Painting" />
                  <label>Painting</label>
                </div>
                <div className="checkbox">
                  <Field type="checkbox" name="hobbies" value="Singing" />
                  <label>Singing</label>
                </div>
                <div className="checkbox">
                  <Field type="checkbox" name="hobbies" value="Travelling" />
                  <label>Travelling</label>
                </div>
                {errors.hobbies && touched.hobbies ? (
                  <div className="error">{errors.hobbies}</div>
                ) : null}
              </div>
            </div>
            <div className="btn-group">
              <button type="submit">REGISTER</button>
              <button type="reset">RESET</button>
            </div>
          </Form>
        )}
      </Formik>
      {showDetails && (
        <div className="register-details">
          <h2>Registration Details</h2>
          <div className="reg-details-container">
            <table>
              <thead>
                <tr>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Email</th>
                  <th>Password</th>
                  <th>Gender</th>
                  <th>Address</th>
                  <th>Country</th>
                  <th>Hobbies</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{details.firstName}</td>
                  <td>{details.lastName}</td>
                  <td>{details.email}</td>
                  <td>{details.password}</td>
                  <td>{details.gender}</td>
                  <td>{details.address}</td>
                  <td>{details.country}</td>
                  <td>{details.hobbies.join(",")}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

export default RegistrationForm;
