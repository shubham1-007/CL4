import "../../assets/css/layout/Header.css";
import logo from "../../assets/images/images.png";
function Header() {
  return (
    <>
      <div className="header-wrapper">
        <div className="logo-img">
          <img src={logo} alt="logo-image"></img>
        </div>
        <div className="logo">
          <h1>ShopEase</h1>
        </div>
      </div>
    </>
  );
}
export default Header;
