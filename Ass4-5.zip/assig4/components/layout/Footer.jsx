import "../../assets/css/layout/Footer.css";
function Footer() {
  var date = new Date();
  var year = date.getFullYear();
  return (
    <div className="footer-wrapper">
      <div className="copyright">&copy; Copyright Shop Ease {year}</div>
      <div>
        <ul className="socials">
          <li className="social">
            <a href="/">Linkedin</a>
          </li>
          <li className="social">
            <a href="/">Instagram</a>
          </li>
          <li className="social">
            <a href="/">Twitter</a>
          </li>
        </ul>
      </div>
    </div>
  );
}

export default Footer;
