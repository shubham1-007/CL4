import React, { useState } from "react";
import "../assets/css/Main.css";
import LoginForm from "./LoginForm";
import RegistrationForm from "./RegistrationForm";

const Main = () => {
  const [showLogIn, setShowLogin] = useState(true);
  const [showRegister, setShowRegister] = useState(false);

  // function to show login Details on login
  const Login = () => {
    setShowLogin(true);
    setShowRegister(false);
  };
  // function to show Register details on register
  const Register = () => {
    setShowRegister(true);
    setShowLogin(false);
  };
  return (
    <div className="forms-wrapper">
      <div className="buttons">
        <button onClick={Login}>Sign In</button>
        <button onClick={Register}>Sign Up</button>
      </div>
      {showLogIn && <LoginForm />}
      {showRegister && <RegistrationForm />}
    </div>
  );
};
export default Main;
