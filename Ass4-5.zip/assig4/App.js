import './App.css';
import Main from "../src/components/Main"
import Header from '../src/components/layout/Header'
import Footer from '../src/components/layout/Footer'
function App() {
  return (
    <div className="App">
      <div className='app-wrapper'>
        <Header></Header>
        <Main></Main>
      </div>
      <Footer></Footer>
    </div>
  );
}

export default App;
