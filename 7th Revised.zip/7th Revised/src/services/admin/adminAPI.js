import axios from "axios";

const url = "http://localhost:3004/users";

const adminAPI = {
  // getting all student list
  getStudentsList: () => axios.get(`${url}?role=Student`),

  // getting details of specific student
  getStudentDetails: (id) => axios.get(`${url}/${id}`),

  // updating topics
  updateStudentTopics: (id, data) => axios.put(`${url}/${id}`, data),
};

export { adminAPI };
