import React, { useEffect, useState } from "react";
import "../../assets/css/student/Student.css";
import { MdOutlineHistoryEdu } from "react-icons/md";
import { FaEarthAsia } from "react-icons/fa6";
import { GiMaterialsScience } from "react-icons/gi";
import { TbMathSymbols } from "react-icons/tb";
import { studentAPI } from "../../services/student/studentAPI";

function Student() {
  const [studentDetails, setStudentDetails] = useState({
    firstName: "",
    lastName: "",
    email: "",
    topics: [],
  });

  const user = localStorage.getItem("loggedUser");
  if (user) {
    var id = JSON.parse(user).id;
  }

  // specifiying the icon
  const topicsIcon = {
    History: <MdOutlineHistoryEdu size={70} color="green" />,
    Geography: <FaEarthAsia size={70} color="green" />,
    Science: <GiMaterialsScience size={70} color="green" />,
    Maths: <TbMathSymbols size={70} color="green" />,
  };

  useEffect(() => {
    if (user) {
      studentAPI.getStudentDetails(id).then((res) => {
        setStudentDetails(res.data);
      });
    }
    // eslint-disable-next-line
  }, [studentDetails]);
  return (
    <div className="student-dashboard-container w-100">
      <div className="student-details">
        <div className="basic-details">
          <h3>{`${studentDetails.firstName} ${studentDetails.lastName}`}</h3>
          <h6>{studentDetails.email}</h6>
        </div>
        <div className="topics-section">
          <h4>Topics</h4>
          <div className="topics">
            {studentDetails.topics.map((topic, i) => {
              return (
                <div className="topic" key={i}>
                  {topic} {topicsIcon[topic]}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Student;
