import React, { useEffect, useState } from "react";
import { Table, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import "../../assets/css/admin/Admin.css";
import { toast, ToastContainer } from "react-toastify";
import { adminAPI } from "../../services/admin/adminAPI";

function Admin() {
  const navigate = useNavigate();
  const [studentsList, setStudentList] = useState([]);

  useEffect(() => {
    // getting list of students
    adminAPI
      .getStudentsList()
      .then((res) => {
        setStudentList(res.data);
      })
      .catch(() => {
        toast.error("Error While Getting Students");
      });
  }, []);

  return (
    <div className="student-list-container">
      <div className="student-list">
        <Table responsive>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Student Email</th>
              <th>Access</th>
              <th>Edit Access</th>
            </tr>
          </thead>
          <tbody>
            {studentsList.map((student, i) => (
              <tr key={i}>
                <td>{student.id}</td>
                <td>{`${student.firstName} ${student.lastName}`}</td>
                <td>{student.email}</td>
                <td>{student.topics.join(", ")}</td>
                <td>
                  <Button
                    onClick={() => navigate(`edit-access/${student.id}`)}
                    variant="primary"
                  >
                    Edit Access
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
      <ToastContainer />
    </div>
  );
}

export default Admin;
