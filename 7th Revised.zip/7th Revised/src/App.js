import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/layout/Layout";
import LoginForm from "./components/Login";
import Admin from "./components/admin/AdminDashboard";
import Student from "./components/student/StudentDashboard";
import Protected from "./Guard/Protected";
import EditAccess from "./components/admin/EditAccess";
import { ToastContainer } from "react-bootstrap";
import "react-toastify/dist/ReactToastify.css";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="*" element={<LoginForm />} />
          <Route index element={<LoginForm />} />
          <Route path="login" element={<LoginForm />} />
          <Route path="admin" element={<Protected Component={Admin} />} />
          <Route
            path="admin/edit-access/:id"
            element={<Protected Component={EditAccess} />}
          />
          <Route path="student" element={<Protected Component={Student} />} />
        </Route>
      </Routes>
      <ToastContainer />
    </BrowserRouter>
  );
}

export default App;
