import React from "react";
import "../../assets/css/layout/Footer.css";

function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="footer">
      <div className="footer-wrapper container">
        <div className="copyright">
          &copy; {year} Farm2Fork. All Rights Reserved.
        </div>
        <div className="social-links">
          <a href="/" className="social-link">
            Facebook
          </a>
          <a href="/" className="social-link">
            Twitter
          </a>
          <a href="/" className="social-link">
            Instagram
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
