import React, { useEffect, useState } from "react";
import "../../assets/css/layout/Header.css";
import { Link } from "react-router-dom";
import logo from "../../assets/images/F2FLogo.png";

function Header() {
  const [isLoggedIn, setLoggedIn] = useState(false);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("loggedUser"));
    if (user) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }
  }, []);

  // Listen for changes to localStorage to update login state in real time
  useEffect(() => {
    const handleStorageChange = () => {
      const user = JSON.parse(localStorage.getItem("loggedUser"));
      if (user) {
        setLoggedIn(true);
      } else {
        setLoggedIn(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary fixed-top mb-4">
        <div className="container-fluid">
          <a className="navbar-brand p-1" href="/">
            <img src={logo} className="mx-3" alt="" height={40} />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            {!isLoggedIn && (
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link to={"/home"} className="nav-link">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/login"} className="nav-link">
                    Get Started
                  </Link>
                </li>
              </ul>
            )}
            {isLoggedIn && (
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link to={"/home"} className="nav-link">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/products"} className="nav-link">
                    Products
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/orders"} className="nav-link">
                    Orders
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/cart"} className="nav-link">
                    Cart
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/login"} className="nav-link">
                    Logout
                  </Link>
                </li>
              </ul>
            )}
          </div>
        </div>
      </nav>
    </div>
  );
}

export default Header;
