import React, { useEffect, useState } from "react";
import "../../assets/css/layout/Header.css";
import { Link } from "react-router-dom";

function Header() {
  // eslint-disable-next-line
  const [isLoggedIn, setLoggedIn] = useState(false);
  const user = JSON.parse(localStorage.getItem("loggedUser"));

  useEffect(() => {
    if (user) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }
    console.log("changed");
  }, [user]);

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-body-tertiary fixed-top mb-4">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">
            Farm2Fork
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            {!user && (
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link to={"/home"} className="nav-link">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/login"} className="nav-link">
                    Get Started
                  </Link>
                </li>
              </ul>
            )}
            {user && (
              <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <Link to={"/home"} className="nav-link">
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/products"} className="nav-link">
                    Products
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/cart"} className="nav-link">
                    Cart
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to={"/login"} className="nav-link">
                    Logout
                  </Link>
                </li>
              </ul>
            )}
          </div>
        </div>
      </nav>
    </div>
  );
}

export default Header;
