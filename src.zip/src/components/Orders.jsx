import React, { useEffect, useState } from "react";
import "../assets/css/Orders.css";
import axios from "axios";
import img from "../assets/images/clients-1-120x114.png";
import { PiCurrencyInr } from "react-icons/pi";

function Orders() {
  const [orders, setOrders] = useState([]);
  const url = "http://localhost:3004/orders";
  const userName = JSON.parse(localStorage.getItem("loggedUser"));

  useEffect(() => {
    console.log(userName);
    axios.get(`${url}?firstName=${userName.name}`).then((res) => {
      setOrders(res.data);
      console.log(res.data);
    });
  }, []);
  return (
    <div className="orders-container">
      <div className="container">
        <div className="row heading-row">
          <h3>Your Orders</h3>
        </div>
        <div className="orders-main-container">
          {orders.length === 0 ? (
            <div className="empty-roder">
              <h1> No Orders Placed</h1>
            </div>
          ) : (
            <div className="row order-row">
              {orders.map((order) => {
                return (
                  <div className="orders-row row mb-3">
                    <h5 className="">{<h4>{`Order Id : ${order.id}`}</h4>}</h5>
                    {order.products.map((product) => {
                      return (
                        <>
                          <div className="product-row col-md-6 col-sm-12 mb-sm-3">
                            <div className="row">
                              <div className="product-img col-5">
                                <img src={img} alt="" height={50} />
                              </div>
                              <div className="prouduct-name col-7 py-3 mr-2">
                                {product.productName}
                              </div>
                            </div>
                          </div>
                          <div className="product-row col-md-6 col-sm-12 d-flex justify-content-end mb-3 ">
                            <div className="row">
                              <div className="col-12 text-md-end text-sm-center">
                                <h6>{`Rs.${product.productPrice}`}</h6>
                              </div>
                              <div className="col-12 text-md-end">
                                {`Qty.${product.quantity}`}
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })}
                    <div className="row order-total">
                      <h6 className="text-end ml-2">
                        {`Order Total: `}
                        <PiCurrencyInr className="mb-1" size={18} />
                        {`${order.total}`}
                      </h6>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Orders;
