import React, { useContext, useState } from "react";
import { ProductContext } from "../productContext/ProductContext";
import { useNavigate } from "react-router-dom";
import "../assets/css/Cart.css";
import { PiCurrencyInr } from "react-icons/pi";
import { IoMdCart } from "react-icons/io";

function Cart() {
  const { productData, quantity, setQuantity, total, setTotal } =
    useContext(ProductContext);
  const [grandTotal, setGrandTotal] = useState(total);
  const navigate = useNavigate();

  //function to handle quantity increase
  const handleIncrease = (index) => {
    const newQuantity = [...quantity];
    newQuantity[index] += 1;
    setQuantity(newQuantity);
    handleTotal(newQuantity);
  };

  // function to handle quantity decrease
  const handleDecrease = (index) => {
    const newQuantity = [...quantity];
    if (newQuantity[index] > 1) {
      newQuantity[index] -= 1;
      setQuantity(newQuantity);
      handleTotal(newQuantity);
    }
  };

  // function to handle total
  const handleTotal = (quantity) => {
    let newGrandTotal = 0;
    for (let i = 0; i < productData.length; i++) {
      newGrandTotal += productData[i].price * quantity[i];
    }

    setGrandTotal(newGrandTotal);
    setTotal(newGrandTotal);
  };

  return (
    <div className="cart-container">
      <div className="cart-wrapper p-3">
        {productData.length !== 0 && <h3>Your Cart</h3>}
        {productData.length <= 0 ? (
          <div className="empty-cart">
            <div className="row cart">
              <div className="col-md-6 col-sm-12 text-center ">
                <h3>No items in the cart</h3>
                <p>Click on the product to add it to the cart</p>
                <IoMdCart size={200} color="#508d4e" />
              </div>
            </div>
          </div>
        ) : (
          <div className="table-responsive w-100">
            <table className="table">
              <thead className="ml-2">
                <tr>
                  <td>
                    <h5>Product</h5>
                  </td>
                  <td>
                    <h5>Price</h5>
                  </td>
                  <td width={200}>
                    <h5>Quantity</h5>
                  </td>
                  <td>
                    <h5>Total</h5>
                  </td>
                </tr>
              </thead>
              <tbody>
                {productData.map((product, i) => (
                  <tr key={product.id}>
                    <td className="product">
                      <div className="row p-4">
                        <div className="col-md-6 product-img">
                          <img
                            src={product.img}
                            alt={product.title}
                            className="img-fluid"
                          />
                        </div>
                        <div className="col-md-4 d-flex justify-content-center align-items-center mt-3">
                          <h6>{product.name}</h6>
                        </div>
                      </div>
                    </td>
                    <td className="pt-5">{product.price}</td>
                    <td className="pt-5">
                      <button
                        className="btn btn-secondary"
                        onClick={() => handleDecrease(i)}
                      >
                        -
                      </button>
                      <span className="quantity mx-3">{quantity[i]}</span>
                      <button
                        className="btn btn-primary"
                        onClick={() => handleIncrease(i)}
                      >
                        +
                      </button>
                    </td>
                    <td className="pt-5">{product.price * quantity[i]}</td>
                  </tr>
                ))}
                <tr>
                  <td colSpan="2" className="text">
                    <h5>Total</h5>
                  </td>
                  <td>
                    <h5>
                      <PiCurrencyInr className="mb-1" size={20} />
                      {grandTotal}
                    </h5>
                  </td>
                  <td>
                    <button
                      className="btn btn-primary"
                      onClick={() => navigate("/checkout")}
                    >
                      Checkout
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default Cart;
