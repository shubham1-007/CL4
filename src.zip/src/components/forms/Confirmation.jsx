import { React, useState, useContext, useEffect } from "react";
import Table from "react-bootstrap/Table";
import { MultiStepContext } from "../../StepContext";
import "../../assets/css/forms/confirmation.css";
import { Button } from "react-bootstrap";
import axios from "axios";

function Confirmation() {
  const url = "http://localhost:3004/user";
  const { step, setStep, stepData } = useContext(MultiStepContext);

  const handleSubmit = () => {
    console.log(stepData);
    axios.post(url, stepData).then((res) => {});
  };

  return (
    <div className="confirmation-page mt-5 pt-5">
      <h3 className="text-center mb-5">Confirmation</h3>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="details-container">
            <h5>User Information</h5>
            <div className="row">
              <div className="col-md-4">First Name : {stepData.firstName}</div>
              <div className="col-md-4">Last Name : {stepData.lastName}</div>
              <div className="col-md-4">Mobile : {stepData.mobile}</div>
            </div>
            <div className="row">
              <div className="col-md-4">Email : {stepData.email}</div>
              <div className="col-md-4">Gender : {stepData.gender}</div>
              <div className="col-md-4">DOB : {stepData.dob}</div>
            </div>
            <div className="row">
              <div className="col-md-4">Address : {stepData.address}</div>
              <div className="col-md-4">Password : {stepData.password}</div>
              <div className="col-md-4">
                Confirm Password : {stepData.confirmPassword}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="details-container">
            <h5>Education Details</h5>
            <div className="row">
              <div className="col-md-6">Specialization : {stepData.degree}</div>
              <div className="col-md-6">University: {stepData.university}</div>
            </div>
            <div className="row">
              <div className="col-md-6">
                Year of Passing : {stepData.yearOfPassing}
              </div>
              <div className="col-md-6">Percentage : {stepData.percentage}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="details-container">
            <h5>Work Experience</h5>
            <div className="row">
              <div className="col-md-6">
                Organization : {stepData.organisation}
              </div>
              <div className="col-md-6">
                Company Address: {stepData.companyAddress}
              </div>
            </div>
            <div className="row">
              <div className="col-md-6">
                Year of Passing : {stepData.yearOfPassing}
              </div>
              <div className="col-md-6">Percentage : {stepData.percentage}</div>
            </div>
          </div>
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="details-container">
            <h5>Photo</h5>
            <div className="row">
              <div className="photo-container col-md-12">
                <div className="image-outer">
                  <img
                    src={stepData.image}
                    width={300}
                    height={300}
                    alt="profile"
                    className="profile-photo"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="buttons">
        <Button onClick={() => setStep(3)}>Back</Button>
        <Button onClick={() => handleSubmit()} variant="primary">
          Submit
        </Button>
      </div>
    </div>
  );
}

export default Confirmation;
