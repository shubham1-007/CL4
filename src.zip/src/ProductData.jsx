import product1 from "./assets/images/product-1.png";
import product2 from "./assets/images/product-2.png";
import product3 from "./assets/images/product-3.png";
import product4 from "./assets/images/product-4.png";
import product5 from "./assets/images/product-5.png";
import product6 from "./assets/images/product-6.png";
import product7 from "./assets/images/product-7.png";

export const ProductData = [
  {
    id: 1,
    name: "Banana",
    price: 100,
    img: product1,
    quantity: 1,
  },
  {
    id: 2,
    name: "Potatoes",
    price: 200,
    img: product2,
    quantity: 1,
  },
  {
    id: 3,
    name: "Carrot",
    price: 50,
    img: product3,
    quantity: 1,
  },
  {
    id: 4,
    name: "Strawberries",
    price: 150,
    img: product4,
    quantity: 1,
  },
  {
    id: 5,
    name: "Cucumber",
    price: 90,
    img: product5,
    quantity: 1,
  },
  {
    id: 6,
    name: "Peppers",
    price: 180,
    img: product6,
    quantity: 1,
  },
  {
    id: 7,
    name: "Melon",
    price: 80,
    img: product7,
    quantity: 1,
  },
  {
    id: 8,
    name: "Strawberries",
    price: 150,
    img: product4,
    quantity: 1,
  },
  {
    id: 9,
    name: "Potatoes",
    price: 200,
    img: product2,
    quantity: 1,
  },
  {
    id: 10,
    name: "Cucumber",
    price: 90,
    img: product5,
    quantity: 1,
  },
];
