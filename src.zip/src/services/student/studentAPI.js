import axios from "axios";

// url
const url = "http://localhost:3004/users";

const studentAPI = {
  getStudentDetails: (id) => axios.get(`${url}/${id}`),
};

export { studentAPI };
