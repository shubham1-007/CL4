import { useState, createContext } from "react";
export const MultiStepContext = createContext();
// storing initial values
const initialValues = {
  firstName: "",
  lastName: "",
  mobile: "",
  email: "",
  gender: "",
  dob: "",
  address: "",
  password: "",
  confirmPassword: "",
  degree: "",
  university: "",
  yearOfPassing: "",
  percentage: "",
  organisation: "",
  companyAddress: "",
  yearsWorked: "",
  designation: "",
  image: "",
};

const StepContext = ({ children }) => {
  const [step, setStep] = useState(0);
  const [stepData, setStepData] = useState(initialValues);
  const [finalData, setFinalData] = useState([]);

  return (
    <div>
      <MultiStepContext.Provider
        value={{
          step,
          setStep,
          stepData,
          setStepData,
          finalData,
          setFinalData,
        }}
      >
        {children}
      </MultiStepContext.Provider>
    </div>
  );
};

export default StepContext;
