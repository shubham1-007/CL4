import { React, useState, useContext, useEffect } from "react";
import Table from "react-bootstrap/Table";
import { MultiStepContext } from "../../StepContext";
import "../../assets/css/forms/confirmation.css";
import { Button } from "react-bootstrap";
import axios from "axios";

function Confirmation() {
  const url = "http://localhost:3004/user";
  const { step, setStep, stepData } = useContext(MultiStepContext);

  const handleSubmit = () => {
    console.log(stepData);
    axios
      .post(url, stepData)
      .then((res) => {
        alert("data posted");
      })
      .catch((err) => {
        alert(err);
      });
  };

  return (
    <div className="confirmation-page my-3">
      <h3 className="text-center">Confirmation</h3>
      <div className="row">
        <div className="photo-container">
          {/* <img src={stepData.photo} alt="profile" className="profile-photo" /> */}
          photo
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="user-details-container">user details container</div>
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
          <div className="education-details-container">education details container</div>
        </div>
      </div>
      <div className="confirmation-row">
        <div className="col-md-10">
        <div className="work-details-container">work details container</div>
        </div>
      </div>
      <div className="btn my-2">
        <Button onClick={() => setStep(3)}>Back</Button>
        <Button onClick={() => handleSubmit()} variant="primary">
          Submit
        </Button>
      </div>
    </div>
  );
}

export default Confirmation;
