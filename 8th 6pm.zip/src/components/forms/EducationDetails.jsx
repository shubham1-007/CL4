import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import { Button } from "react-bootstrap";
import * as Yup from "yup";
import { useContext } from "react";
import { MultiStepContext } from "../../StepContext";

function EducationDetails() {
  const initialValues = {
    specilization: "",
    university: "",
    yearOfPassing: "",
    percentage: "",
  };
  const [educationDetails, setEducationDetails] = useState(initialValues);
  const { step, setStep, stepData, setStepData } = useContext(MultiStepContext);
  const [isSubmit, setIsSubmit] = useState(false);

  useEffect(() => {
    if (stepData) {
      setEducationDetails(stepData);
    }
  }, [stepData]);

  // defining userInfo for validation
  const educationDetailsSchema = Yup.object().shape({
    specilization: Yup.string().required("specialization is required"),
    university: Yup.string().required("University is required"),
    yearOfPassing: Yup.string().required("Year of Passing is required"),
    percentage: Yup.string().required("Percentage is required"),
  });
  return (
    <div className="registraion-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={educationDetails}
        // validationSchema={educationDetailsSchema}
        enableReinitialize={true}
        onSubmit={(values) => {
          setIsSubmit(true);
          setStepData(values);
        }}
      >
        {({ errors, touched }) => (
          <Form className="user-info-form my-4">
            <div className="row my-2">
              <h1>Education Details</h1>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group dropdown">
                  <label htmlFor="specilization">Specialization</label>
                  <Field name="specialization" as="select">
                    <option value="">select</option>
                    <option value="be">B. E.</option>
                    <option value="bcom">B. Com</option>
                    <option value="bsc">B.Sc</option>
                  </Field>
                  {errors.specilization && touched.specilization ? (
                    <div className="error">{errors.specilization}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="university">University</label>
                  <Field name="university" className="form-control" />
                  {errors.university && touched.university ? (
                    <div className="error">{errors.university}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="row justify-content-between">
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="yearOfPassing">Year of Passing</label>
                  <Field name="yearOfPassing" className="form-control" />
                  {errors.yearOfPassing && touched.yearOfPassing ? (
                    <div className="error">{errors.yearOfPassing}</div>
                  ) : null}
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-group">
                  <label htmlFor="percentage">Percentage</label>
                  <Field name="percentage" className="form-control" />
                  {errors.percentage && touched.percentage ? (
                    <div className="error">{errors.percentage}</div>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="roww my-5 ">
              <div className="col-md-10 d-flex justify-content-between">
                <Button onClick={() => setStep(0)}>Back</Button>
                <Button type="submit">Save</Button>
                <Button
                  disabled={!isSubmit}
                  onClick={() => setStep((step + 1) % 5)}
                >
                  Next
                </Button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default EducationDetails;
