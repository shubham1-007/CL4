import React from "react";
import "../../assets/css/layout/Layout.css"
function Footer() {
  // getting year from date
  var date = new Date();
  var year = date.getFullYear();
  return (
    <div className="footer">
      <div className="footer-wrapper d-flex justify-content-center">
        <div className="copyright">&copy; Copyright Teams Manager {year}</div>
      </div>
    </div>
  );
}

export default Footer;
