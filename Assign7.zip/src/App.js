import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Layout from "./components/layout/Layout";
import LoginForm from "./components/LoginForm";
import Admin from "./components/Admin";
import Student from "./components/Student";
import Protected from "./components/Protected";
import EditAccess from "./components/EditAccess";
import "react-toastify/dist/ReactToastify.css";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="*" element={<LoginForm />} />
          <Route index element={<LoginForm />} />
          <Route path="login" element={<LoginForm />} />
          <Route path="admin" element={<Protected Component={Admin} />}></Route>
          <Route path="admin/edit-access/:id" element={<EditAccess />} />
          <Route path="student" element={<Protected Component={Student} />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
