import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Nav, Navbar } from "react-bootstrap";
import logo from "../../assets/images/lms.png";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Header = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const user = JSON.parse(localStorage.getItem("loggedUser"));
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    toast.success("logged Out");
    setTimeout(() => {
      navigate("/login");
    }, 1000);
  };

  return (
    <div className="header">
      <Navbar collapseOnSelect expand="lg" className="navbar">
        <Container>
          <Navbar.Brand href="#home">
            <img
              src={logo}
              width="120"
              height="75"
              className="d-inline-block align-top"
              alt="React Bootstrap logo"
            />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="ms-auto">
              <div className="greeting mt-2 mx-3">
                {user && (
                  <h5 className="greeting">
                    {user.role === "Student"
                      ? `Welcome ${user.firstName} ${user.lastName}`
                      : `Welcome ${user.firstName}`}
                  </h5>
                )}
              </div>
              {!loggedIn ? (
                <Nav.Link as={Link} to={"/login"}></Nav.Link>
              ) : (
                <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <ToastContainer />
    </div>
  );
};

export default Header;
