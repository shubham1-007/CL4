import React, { useEffect, useState } from "react";
import "../assets/css/Student.css";
import { MdOutlineHistoryEdu } from "react-icons/md";
import { FaEarthAsia } from "react-icons/fa6";
import { GiMaterialsScience } from "react-icons/gi";
import { TbMathSymbols } from "react-icons/tb";

import axios from "axios";
function Student() {
  const [student, setStudent] = useState({
    firstName: "",
    lastName: "",
    email: "",
    topics: [],
  });
  // url for getting student details
  const url = "http://localhost:3004/users";
  const id = JSON.parse(localStorage.getItem("loggedUser")).id;
  // specifiying the icon 
  const topicsIcon = {
    History : <MdOutlineHistoryEdu size={70} color="green" />,
    Geography : <FaEarthAsia size={70} color="green" />,
    Science : <GiMaterialsScience size={70} color="green" />,
    Maths : <TbMathSymbols size={70} color="green" />
  }
  
  useEffect(() => {
    axios.get(`${url}/${id}`).then((res) => {
      setStudent(res.data);
    });
  }, []);
  return (
    <div className="student-dashboard-container w-100">
      <div className="student-details">
        <div className="basic-details">
          <h3>{`${student.firstName} ${student.lastName}`}</h3>
          <h6>{`${student.email}`}</h6>
        </div>
        <div className="topics-section">
        <h4>Topics</h4>
          <div className="topics">
            {student.topics.map((topic, i) => {
              return (
                <div className="topic" key={i}>
                  {topic} {topicsIcon[topic]}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Student;
