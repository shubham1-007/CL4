import React, { useEffect, useState } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import "../assets/css/EditAccess.css";
import { Button } from "react-bootstrap";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
function EditAccess() {
  const [user, setUser] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    role: "",
    topics: [],
  });

  // getting id for editing topics
  let { id } = useParams();
  //url
  const url = "http://localhost:3004/users";

  useEffect(() => {
    axios.get(`${url}/${id}/`).then((res) => {
      setUser(res.data);
    });
  }, []);
  //instance of navigate
  const navigate = useNavigate();

  // function to edit the topics
  const editTopics = (user) => {
    axios.put(`${url}/${id}`, user).then((res) => {
      toast.success("Post edited Successfully !");
      setTimeout(() => {
        navigate("/admin");
      }, 1000);
    }).catch((err)=>{
      toast.error("Error in Editing post");
    });
  };

  // defining subjects schema
  const topicSchema = Yup.object().shape({});

  return (
    <div className="edit-access-container w-100">
      <div className="edit-access-header">
        <h3>Edit Access</h3>
      </div>
      <div className="edit-access-body">
        <Formik
          initialValues={user}
          validationSchema={topicSchema}
          enableReinitialize={true}
          onSubmit={(values, { resetForm }) => {
            setUser(values);
            editTopics(values);
            resetForm();
          }}
        >
          {({ errors, touched }) => (
            <div className="form-wrapper">
              <Form>
                <div className="form-groups">
                  <div className="form-group">
                    <label htmlFor="checkbox">Topics</label>
                    <div className="topics">
                      <div className="first">
                        <div className="checkbox">
                          <label>
                            <Field
                              type="checkbox"
                              name="topics"
                              value="History"
                            />
                            History
                          </label>
                        </div>
                        <div className="checkbox">
                          <label>
                            <Field
                              type="checkbox"
                              name="topics"
                              value="Geography"
                            />
                            Geography
                          </label>
                        </div>
                      </div>
                      <div className="second">
                        <div className="checkbox">
                          <label>
                            <Field
                              type="checkbox"
                              name="topics"
                              value="Science"
                            />
                            Science
                          </label>
                        </div>
                        <div className="checkbox">
                          <label>
                            <Field
                              type="checkbox"
                              name="topics"
                              value="Maths"
                            />
                            Maths
                          </label>
                        </div>
                      </div>
                    </div>
                    {errors.topics && touched.topics ? (
                      <div className="error">{errors.topics}</div>
                    ) : null}
                  </div>
                  <div className="edit-btn-group">
                    <Button type="submit" variant="primary">
                      Submit
                    </Button>
                    <Button
                      type="button"
                      variant="secondary"
                      onClick={() => {
                        navigate(-1);
                      }}
                    >
                      Back
                    </Button>
                  </div>
                </div>
              </Form>
            </div>
          )}
        </Formik>
      </div>
      <ToastContainer />
    </div>
  );
}

export default EditAccess;
