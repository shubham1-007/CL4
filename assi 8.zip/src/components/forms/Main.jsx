import React, { useContext } from "react";
import { Button } from "react-bootstrap";
import { Stepper, Step, StepLabel } from "@mui/material";
import UserInfo from "./UserInfo";
import EducationDetails from "./EducationDetails";
import { MultiStepContext } from "../../StepContext";
import WorkExperience from "./WorkExperience";
import PhotoUploadation from "./PhotoUploadation";
import Confirmation from "./Confirmation";
import "../../assets/css/Main.css";

function Main() {
  const { step, setStep } = useContext(MultiStepContext);

  function showStep(step) {
    switch (step) {
      case 0:
        return <UserInfo />;
      case 1:
        return <EducationDetails />;
      case 2:
        return <WorkExperience />;
      case 3:
        return <PhotoUploadation />;
      case 4:
        return <Confirmation />;
      default:
        return <div>Return to home</div>;
    }
  }

  return (
    <div className="container my-4">
      <div className="row justify-content-center">
        <div className="col-md-8 ">
          <Stepper activeStep={step} orientation="horizontal">
            <Step>
              <StepLabel>Step 1</StepLabel>
            </Step>
            <Step>
              <StepLabel>Step 2</StepLabel>
            </Step>
            <Step>
              <StepLabel>Step 3</StepLabel>
            </Step>
            <Step>
              <StepLabel>Step 4</StepLabel>
            </Step>
            <Step>
              <StepLabel>Step 5</StepLabel>
            </Step>
          </Stepper>
          <div className="row">
            <div className="col-md-12">
              <div className="forms-container">{showStep(step)}</div>
            </div>
          </div>
          <div className="row ">
            <div className="col-md-12 d-flex justify-content-between">
              <Button onClick={() => setStep(step !== 0 && step - 1)}>
                Back
              </Button>
              <Button onClick={() => setStep((step + 1) % 5)}>Next</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Main;
