import React from 'react'

function PhotoUploadation() {
  return (
    <div>PhotoUploadation</div>
  )
}

export default PhotoUploadation