import React from "react";

function EducationDetails() {
  return <div>EducationDetails</div>;
}

export default EducationDetails;
