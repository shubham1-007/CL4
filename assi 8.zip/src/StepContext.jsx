import { useState, createContext } from "react";
import Main from "./components/forms/Main";

export const MultiStepContext = createContext();
const StepContext = () => {
  const [step, setStep] = useState(1);
  const [stepData, setStepData] = useState([]);
  const [finalData, setFinalData] = useState([]);

  return (
    <div>
      <MultiStepContext.Provider
        value={{
          step,
          setStep,
          stepData,
          setStepData,
          finalData,
          setFinalData,
        }}
      >
        <Main />
      </MultiStepContext.Provider>
    </div>
  );
};

export default StepContext;
