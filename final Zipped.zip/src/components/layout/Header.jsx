import React from "react";
import "../../assets/css/layout/Header.css";
import logo from "../../assets/images/logo.png";
import { Nav } from "react-bootstrap";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Header() {
  // state to store logged user
  const [loggedIn, setLoggedIn] = useState(false);
  //getting user
  const user = localStorage.getItem("user");
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }
  }, [user]);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setTimeout(() => {
      toast.success("logged Out");
    }, 500);
    navigate("/login");
  };

  return (
    <div>
      <div className="header">
        <div className="nav-container">
          <div className="navbar-brand">
            <img
              alt=""
              src={logo}
              width="70"
              height="70"
              className="d-inline-block align-center"
            />
            <div className="divider"></div>
            <div className="brand-text">
              <h1>Cricket Team Manager</h1>
            </div>
          </div>
          {loggedIn && (
            <div className="row menu-items">
              <div className="col-md-6">
                <h5 className="mt-2">{`Hello ${user}`}</h5>
              </div>
              <div className="col-md-4">
                <Nav.Link onClick={handleLogout}>Logout</Nav.Link>
              </div>
            </div>
          )}
        </div>
      </div>
      <ToastContainer />
    </div>
  );
}

export default Header;


