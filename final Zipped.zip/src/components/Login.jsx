import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import "../assets/css/LoginForm.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// storing initial values
const initialUserCredentials = {
  email: "",
  password: "",
};

function LoginForm() {
  // state to store the DB credentials
  const [dbcredentials, setDBCredentials] = useState([]);

  useEffect(() => {
    if(localStorage.getItem('user')){
      localStorage.removeItem('user')
    }
    getCredentials();
    // eslint-disable-next-line
  }, []);

  //api url
  const url = "http://localhost:3004/users/";

  // function to get the database user credentials
  const getCredentials = () => {
    axios.get(url).then((res) => {
      setDBCredentials(res.data);
    });
  };

  // function to login
  const login = (credentials) => {
    const loggedUser = dbcredentials.find(
      (dbUser) =>
        dbUser.email === credentials.email &&
        dbUser.password === credentials.password
    );

    if (loggedUser) {
      // storing user to localstorage
      localStorage.setItem("user", loggedUser.firstName);
      toast.success("Logged In (Admin)");
      setTimeout(() => {
        navigate("/dashboard");
      }, 500);
    } else {
      toast.error("Invalid Credentials");
    }
  };

  const navigate = useNavigate();
  // defining registrationSchema for validation
  const loginSchema = Yup.object().shape({
    email: Yup.string().email("Invalid email").required("Email is required"),

    password: Yup.string()
      .min(8, "Password must be 8 letters long")
      .max(16, "Password must be less than 16 letters")
      .required("Password is Required")
      .matches(
        /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/,
        "Password must contain atleast a digit a lowercase, a uppercase ,special charcter and a digit"
      ),
  });

  return (
    <div className="login-container">
      {/* using Formik for Form  */}
      <Formik
        initialValues={initialUserCredentials}
        validationSchema={loginSchema}
        onSubmit={(values, { resetForm }) => {
          login(values);
          resetForm();
        }}
      >
        {({ errors, touched }) => (
          <Form className="login-form">
            <div className="row">
              <div className="col-md-6">
                <h2>Login </h2>
              </div>
            </div>
            <div className="inputs">
              <div className="row input-row">
                <div className="col-md-10">
                  <div className="form-group">
                    <label htmlFor="email"> Email</label>
                    <Field name="email" type="email" className="form-control"/>
                    {errors.email && touched.email ? (
                      <div className="error">{errors.email}</div>
                    ) : null}
                  </div>
                </div>
              </div>
              <div className="row input-row">
                <div className="col-md-10">
                  {/* password  */}
                  <div className="form-group">
                    <div className="div">
                      <label htmlFor="password"> Password</label>
                    </div>
                    <Field name="password" type="password" className="form-control" />
                    {errors.password && touched.password ? (
                      <div className="error">{errors.password}</div>
                    ) : null}
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="btn-group">
                <Button className="mx-3" type="reset" variant="secondary">
                  RESET
                </Button>
                <Button type="submit" variant="primary">
                  Login
                </Button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
      <ToastContainer />
    </div>
  );
}

export default LoginForm;

