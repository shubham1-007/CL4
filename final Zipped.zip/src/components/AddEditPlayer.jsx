import { React, useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Formik, Field, Form } from "formik";
import * as Yup from "yup";
import { Button } from "react-bootstrap";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../assets/css/AddEditPlayer.css";
import "react-datepicker/dist/react-datepicker.css";

function AddEdit() {
  // getting id for editing player info
  let { id } = useParams();

  //state to store todays's date
  const [date, setDate] = useState(new Date());

  // api url
  const url = "http://localhost:3004";

  //storing teams from Database
  const [teams, setTeams] = useState([]);

  const [initialValues, setInitialValues] = useState({
    firstName: "",
    lastName: "",
    dob: "",
    contractAmount: "",
    totalMatches: "",
    teamTitle: "",
    specification: [],
    history: "",
  });

  // calling get api for edit post
  useEffect(() => {
    if (id) {
      getPlayerInfo(id);
    }
    getTeams();
    getFormattedDate();
    // eslint-disable-next-line
  }, []);
  // instance of Navigate
  const navigate = useNavigate();

  //function to get the player details for given id
  const getPlayerInfo = () => {
    axios.get(`${url}/players/${id}`).then((res) => {
      setInitialValues(res.data);
    });
  };

  //function to edit the Playerinfo
  const editPlayerInfo = (data) => {
    axios
      .put(`${url}/players/${id}`, data)
      .then((res) => {
        setInitialValues(res.data);
        toast.success("Post Edited");
      })
      .catch((err) => {
        toast.error("Error Editing Post");
      });
  };

  //function to add new post
  const addPlayerInfo = (data) => {
    axios
      .post(`${url}/players`, data)
      .then((res) => {
        setInitialValues(res.data);
        toast.success("New Player Added Succesfully ");
      })
      .catch((err) => {
        toast.error("Error Adding New Player");
      });
  };

  //getting teams from database
  const getTeams = () => {
    axios.get(`${url}/teams`).then((res) => {
      setTeams(res.data);
    });
  };

  // function to get the formattd date
  const getFormattedDate = () => {
    let today = new Date();
    let year = today.getFullYear();
    let month = String(today.getMonth() + 1).padStart(2, "0");
    let day = String(today.getDate()).padStart(2, "0");
    setDate(`${year}-${month}-${day}`);
  };

  //validation schema for query info
  const playerSchema = Yup.object().shape({
    firstName: Yup.string()
      .trim()
      .matches(/^[a-zA-Z]+$/, "First Name must be alphabetical")
      .min(4, "First Name must be atleast 4 letters long")
      .max(15, "First Name must be atmost 25 letters long")
      .required("First Name is required"),

    lastName: Yup.string()
      .trim()
      .matches(/^[a-zA-Z]+$/, "Last Name must be alphabetical")
      .min(4, "Last Name must be atleast 4 letters long")
      .max(15, "Last Name must be atmost 15 letters long")
      .required("Last Name is required"),

    dob: Yup.string().required("Date of birth is required"),

    contractAmount: Yup.number()
      .min(1000, "Contract Amount must be greater than 999")
      .max(100000, "Contract Amount must be less than 10,0000")
      .required("Contract amount is required"),

    totalMatches: Yup.string()
      .matches(/^[0-9]+$/, "Total Matches must be a whole Number")
      .required("Total Matches is Required"),

    teamTitle: Yup.string().required("Team Title is required"),

    specification: Yup.array()
      .required("Please Select Specification")
      .min(1, "Please select at least one specification"),

    history: Yup.string().required("History is required")
    .trim()
    .matches(/^[A-Za-z0-9 _]*[A-Za-z0-9][A-Za-z0-9 _]*$/, "History must be alphanumric"),
  });

  return (
    <div>
      <div className="player-form-wrapper">
        <Formik
          initialValues={initialValues}
          validationSchema={playerSchema}
          enableReinitialize={true}
          onSubmit={(values, { resetForm }) => {
            setInitialValues(values);
            if (id) {
              editPlayerInfo(values);
            } else {
              addPlayerInfo(values);
            }
            navigate("/dashboard");
            resetForm();
          }}
        >
          {({ errors, touched }) => (
            <Form>
              <div className="container player-form">
                <div className="row">
                  <div className="player-form-header">
                    <h1>{id ? "Edit Player" : "Add Player"}</h1>
                    <Button
                      type="button"
                      className="close"
                      aria-label="Close"
                      variant="danger"
                      onClick={() => navigate("/dashboard")}
                    >
                      <span aria-hidden="true">&times;</span>
                    </Button>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="first-name">First Name</label>
                      </div>
                      <Field name="firstName" className="form-control" />
                      {errors.firstName && touched.firstName ? (
                        <div className="error">{errors.firstName}</div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="last-name">Last Name</label>
                      </div>
                      <Field name="lastName" className="form-control" />
                      {errors.lastName && touched.lastName ? (
                        <div className="error">{errors.lastName}</div>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="dob">Date of Birth</label>
                      </div>
                      <Field
                        type="date"
                        name="dob"
                        max={date}
                        className="form-control"
                      />
                      {errors.dob && touched.dob ? (
                        <div className="error">{errors.dob}</div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="contractAmount">Contract Amount</label>
                      </div>
                      <Field
                        name="contractAmount"
                        type="number"
                        className="form-control"
                      />
                      {errors.contractAmount && touched.contractAmount ? (
                        <div className="error">{errors.contractAmount}</div>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="totalMatches">Total Matches</label>
                      </div>
                      <Field
                        name="totalMatches"
                        inputMode="numeric"
                        type="number"
                        className="form-control"
                      />
                      {errors.totalMatches && touched.totalMatches ? (
                        <div className="error">{errors.totalMatches}</div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="teamTitle">Team</label>
                      </div>
                      <Field
                        name="teamTitle"
                        className="team-dropdown"
                        as="select"
                      >
                        <option value="" className="form-control">
                          Select Team
                        </option>
                        {teams.map((team, i) => {
                          return (
                            <option key={i} value={team}>
                              {team}
                            </option>
                          );
                        })}
                      </Field>
                      {errors.teamTitle && touched.teamTitle ? (
                        <div className="error">{errors.teamTitle}</div>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div className="row ">
                  <div className="col-md-6">
                    <div className="form-group">
                      <div>
                        <label htmlFor="history">History</label>
                      </div>
                      <Field
                        name="history"
                        className="history-text"
                        as="textarea"
                      />
                      {errors.history && touched.history ? (
                        <div className="error">{errors.history}</div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group ">
                      <label htmlFor="specification">Specification</label>
                      <div className="checkbox">
                        <label>
                          <Field
                            type="checkbox"
                            name="specification"
                            value="batting"
                            className="mx-2"
                          />
                          Batting
                        </label>
                      </div>
                      <div className="checkbox">
                        <Field
                          type="checkbox"
                          name="specification"
                          value="bowling"
                          className="mx-2"
                        />
                        <label>Bowling</label>
                      </div>
                      {errors.specification && touched.specification ? (
                        <div className="error">{errors.specification}</div>
                      ) : null}
                    </div>
                  </div>
                </div>
                <div className="row buttons mt-5">
                  <div className="btn-group">
                    <Button type="reset" variant="secondary">
                      Reset
                    </Button>
                    <Button
                      className="mx-4"
                      type="submit"
                      variant={id ? "primary" : "primary"}
                    >
                      {id ? "Edit" : "Add"}
                    </Button>
                  </div>
                </div>
              </div>
            </Form>
          )}
        </Formik>
      </div>
      <ToastContainer />
    </div>
  );
}

export default AddEdit;
