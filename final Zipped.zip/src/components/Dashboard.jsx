import React, { useEffect, useState } from "react";
import axios from "axios";
import Table from "react-bootstrap/Table";
import "../assets/css/Dashboard.css";
import { useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Dashboard() {
  // api url
  const url = "http://localhost:3004/players";
  const [allPlayers, setAllPlayers] = useState([]);
  const navigate = useNavigate();

  // getting all posts from the api
  useEffect(() => {
    getallPlayers();
  }, []);

  //function to geta all posts
  const getallPlayers = () => {
    axios.get(url).then((res) => {
      setAllPlayers(res.data);
    });
  };

  //function to add new Player
  const addPlayerInfo = () => {
    navigate("/add");
  };

  //function to handle Edit player info
  const editPlayerInfo = (id) => {
    navigate(`/edit/${id}`);
  };

  //  function ot handle delet player info
  const handleDelete = (playerId) => {
    // Display confirmation toast
    toast.warning(
      <div>
        <p>Are you sure you want to delete this Player?</p>
        <button
          className="btn btn-danger btn-sm mx-1"
          onClick={() => deletePost(playerId)}
        >
          Yes
        </button>
        <button
          className="btn btn-secondary btn-sm mx-1"
          onClick={() => toast.dismiss()}
        >
          No
        </button>
      </div>,
      {
        position: "top-center",
        autoClose: 1000,
        hideProgressBar: false,
      }
    );
  };

  // function to delete the post
  const deletePost = (playerId) => {
    axios
      .delete(`${url}/${playerId}`)
      .then((res) => {
        toast.success("Player Information Deleted", {
          position: "top-center",
          autoClose: 500,
          hideProgressBar: true,
        });
        getallPlayers();
      })
      .catch((error) => toast.error("Failed to Delete Post!"));
  };

  return (
    <div className="players-container mt-3">
      <div className="btn-container w-100">
        <Button variant="primary mb-1" onClick={() => addPlayerInfo()}>
          Add Player
        </Button>
      </div>
      {allPlayers.length === 0 ? (
        <>
          <h1>Players here..</h1>
          <h3>Please add Players</h3>
        </>
      ) : (
        <div className="table-container">
          <Table responsive>
            <thead className="table-primary">
              <tr>
                <th>Team Title</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>DOB</th>
                <th>Contract Amount</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {allPlayers
                .sort((a, b) => b.id - a.id)
                .map((player, i) => {
                  return (
                    <tr key={i}>
                      <td>{player.teamTitle}</td>
                      <td>{player.firstName}</td>
                      <td>{player.lastName}</td>
                      <td>{player.dob}</td>
                      <td>{player.contractAmount}</td>
                      <td>
                        <div className="actions-btn-group">
                          <Button
                            onClick={() => editPlayerInfo(player.id)}
                            varient="primary"
                          >
                            Edit
                          </Button>
                          <Button
                            onClick={() => handleDelete(player.id)}
                            variant="danger"
                          >
                            Delete
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
          <ToastContainer />
        </div>
      )}
    </div>
  );
}

export default Dashboard;
