import "./App.css";
import { BrowserRouter, Route, Routes,redirect } from "react-router-dom";
import Layout from "./components/layout/Layout";
import Dashboard from "./components/Dashboard";
import AddEdit from "./components/AddEditPlayer";
import Login from "./components/Login";
import Protected from "./guard/Protected";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="*" element={<Login />}/>
          <Route index element={<Login />} />
          <Route path="login" element={<Login />} />
          <Route
            path="dashboard"
            element={<Protected Component={<Dashboard />} />}
          />
          <Route path="add" element={<Protected Component={<AddEdit />} />} />
          <Route
            path="edit/:id"
            element={<Protected Component={<AddEdit />} />}
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
