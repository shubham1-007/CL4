import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function Protected(props) {
  const Component = props.Component;

  // instance of useNavigate for navigation
  const navigate = useNavigate();
  // getting user from local storage
  let user = localStorage.getItem("user");

  useEffect(() => {
    if (!user) {
      navigate("/login");
    }
  });

  return <div>{Component}</div>;
}

export default Protected;
