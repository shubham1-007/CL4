import React, { Component, useEffect } from 'react'
import { redirect, useNavigate } from 'react-router-dom';


function Protected(props) {
  const {Component} = props;
  const navigate = useNavigate()
  useEffect(() => {
    var user = JSON.parse(localStorage.getItem('loggedUser'));
    if (!user) {
      navigate('/login')
    }
  },[])
  return (
    <Component />
  )
}

export default Protected