import React from 'react'

function Student() {
  return (
    <div>Student</div>
  )
}

export default Student