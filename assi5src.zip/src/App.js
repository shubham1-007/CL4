import "./App.css";
import LoginForm from "../src/components/LoginForm";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import RegistrationForm from "./components/RegistrationForm";
import Layout from "./components/layout/Layout";
import ContactUs from "./components/ContactUs";
import Home from "./components/Home";
import RegisterDetails from "./components/RegisterDetails";
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route path="*" element={<Home />} />
          <Route index element={<Home />} />
          <Route path="Home" element={<Home />} />
          <Route path="Contact-Us" element={<ContactUs />} />
          <Route path="Login" element={<LoginForm />} />
          <Route path="Register" element={<RegistrationForm />}>
            <Route path="Details" element={<RegisterDetails />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
